-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 04, 2017 at 11:57 AM
-- Server version: 10.1.26-MariaDB-1~jessie
-- PHP Version: 5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `apollo_4_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `latitude` float(10,7) NOT NULL,
  `longitude` float(10,7) NOT NULL,
`postNumber` int(16) NOT NULL,
  `address1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` int(8) NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USA',
  `postDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`latitude`, `longitude`, `postNumber`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `postDate`) VALUES
(34.0657959, -106.9014282, 12, '716 Sunset Dr', '123', 'Socorro', 'New Mexico', 87801, 'USA', '2017-11-27 22:14:17'),
(34.0624657, -106.9086227, 16, '1208 South Drive', '', 'Socorro', 'NM', 87801, 'United States', '2017-11-29 22:10:57'),
(34.0710449, -106.9052582, 17, '1099 Cassity Place', '9', 'Socorro', 'NM', 87801, 'United States', '2017-11-29 22:43:36'),
(34.0686836, -106.9023666, 18, '1001 Bursum Place', '', 'Socorro', 'NM', 87801, 'United States', '2017-11-29 22:56:30'),
(34.0756836, -106.9057083, 26, '1212 Sean Avenue', '', 'Socorro', 'NM', 87801, 'United States', '2017-11-30 02:35:11'),
(34.0603027, -106.9002609, 27, 'Torres Hall', '', 'Socorro', 'NM', 87801, 'United States', '2017-11-30 03:51:35'),
(34.0754890, -106.8993988, 28, '1221 El Camino Real Street', '', 'Socorro', 'NM', 87801, 'United States', '2017-11-30 05:48:48'),
(40.7608261, -73.9862213, 29, '235 West 48th Street', '', 'New York', 'NY', 10036, 'United States', '2017-11-30 05:50:07'),
(34.0624657, -106.9086227, 30, '1208 South Drive', '', 'Socorro', 'NM', 87801, 'United States', '2017-11-30 06:11:04'),
(34.0603218, -106.9002838, 32, '503 Neel Avenue', '', 'Socorro', 'NM', 87801, 'United States', '2017-11-30 06:49:38'),
(34.0590134, -106.8944550, 33, '208 School of Mines Road', '', 'Socorro', 'NM', 87801, 'United States', '2017-12-01 23:09:32'),
(34.0558739, -106.8980408, 34, '207 Eaton Avenue', '207 1/2 of a duplex', 'Socorro', 'NM', 87801, 'United States', '2017-12-03 20:35:06'),
(34.0811729, -106.9038239, 35, '636 Gianera Street', '', 'Socorro', 'NM', 87801, 'United States', '2017-12-03 20:40:26'),
(34.0678101, -106.9041519, 36, '801 Leroy Place', 'Cramer', 'Socorro', 'NM', 87801, 'United States', '2017-12-03 20:41:47');

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `postNumber` int(16) NOT NULL,
  `email` varchar(320) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(16) NOT NULL,
  `bedrooms` int(11) NOT NULL,
  `bathrooms` int(11) NOT NULL,
  `leaseLength` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `furnished` tinyint(1) NOT NULL,
  `leaseType` int(11) NOT NULL,
  `lateFee` int(11) NOT NULL,
  `lateDays` int(11) NOT NULL,
  `paymentMethods` int(11) NOT NULL,
  `deposit` int(11) NOT NULL,
  `depositReturned` int(11) NOT NULL,
  `receiptGiven` tinyint(1) NOT NULL,
  `utilities` tinyint(1) NOT NULL,
  `appliances` int(11) NOT NULL,
  `cooling` int(11) NOT NULL,
  `heating` tinyint(1) NOT NULL,
  `parking` int(11) NOT NULL,
  `smoking` tinyint(1) NOT NULL,
  `petsAllowed` tinyint(1) NOT NULL,
  `petDeposit` int(11) NOT NULL,
  `petWeight` int(11) NOT NULL,
  `petSize` int(11) NOT NULL,
  `lawnMaintenance` tinyint(1) NOT NULL,
  `responseTime` int(11) NOT NULL,
  `maintenanceTime` int(11) NOT NULL,
  `maintenanceQuality` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `overallThoughts` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `overallRating` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`postNumber`, `email`, `price`, `bedrooms`, `bathrooms`, `leaseLength`, `furnished`, `leaseType`, `lateFee`, `lateDays`, `paymentMethods`, `deposit`, `depositReturned`, `receiptGiven`, `utilities`, `appliances`, `cooling`, `heating`, `parking`, `smoking`, `petsAllowed`, `petDeposit`, `petWeight`, `petSize`, `lawnMaintenance`, `responseTime`, `maintenanceTime`, `maintenanceQuality`, `overallThoughts`, `overallRating`) VALUES
(12, 'john@student.nmt.edu', 1200, 4, 2, 'One Year', 0, 2, 50, 5, 1, 600, 600, 1, 1, 1, 1, 1, 1, 0, 1, 100, 25, 5, 0, 125, 12, 'Great Maintenance Quality ', 'Great location', 4),
(16, 'iseah.olguin@student.nmt.edu', 340, 2, 2, 'one year', 1, 2, 25, 1, 3, 100, 100, 1, 0, 7, 1, 1, 6, 0, 0, -1, -1, 0, 0, 4, 7, 'The quality itself is garbage. ', 'Garbage sauce. In fact, too much sauce. ', 1),
(17, 'johnathan.smith@student.nmt.edu', 100, 1, 1, 'whoKnows', 1, 1, 100, 2, 1, 1, 10, 1, 0, 2, 4, 1, 2, 1, 0, -1, -1, 0, 0, 1, 1, 'stuff', 'stuff. meh', 3),
(18, 'iseah.olguin@student.nmt.edu', 465, 3, 2, 'one year', 0, 2, 35, 5, 7, 200, 200, 0, 0, 15, 1, 1, 12, 0, 1, 0, 145, 4, 0, 31, 60, 'The overall maintenance quality is decent. When it gets done, that is. ', 'I love the location of this property, which is probably why I deal with the crazy amount of traffic and the overall price. ', 4),
(26, 'Kevin.Gomez@student.nmt.edu', 1100, 3, 2, 'one year', 0, 2, 25, 2, 5, 700, 350, 0, 0, 15, 1, 1, 6, 0, 1, 100, 200, 4, 0, 2, 7, 'Maintenance is taken care of within a week''s notice. Overall quality of maintenance is done quite well.', 'The house is quite far but overall quite beautiful and, the current landlord is decent at maintaining the property. ', 4),
(27, 'o@student.nmt.edu', 600, 1, 4, 'Per Semester ', 1, 2, 0, 0, 4, 50, 50, 1, 1, 10, 1, 1, 8, 0, 0, -1, -1, 0, 1, 1, 2, 'Solid Work.', 'None. ', 3),
(28, 'Blah@student.nmt.edu', 900, 3, 1, 'One Year ', 0, 2, 75, 5, 2, 900, 800, 0, 0, 7, 2, 1, 12, 1, 0, -1, -1, 0, 1, 15, 60, 'Terrible. The "maintenance man" tended to be some poor lad the landlady picked up.', 'This rental is about 0.9 miles from NMT and it''s an ok place to rent if you are ok with never getting anything repaired.', 2),
(29, '11@student.nmt.edu', 8795, 2, 2, 'one year', 1, 2, 200, 3, 7, 3000, 1500, 1, 1, 15, 1, 1, 14, 0, 1, 400, 180, 4, 1, 2, 3, 'Staff is absolutely profound. ', 'Beautiful view with a more modern environment. ', 1),
(30, 'blah.blah@student.nmt.edu', 450, 2, 1, 'Six Months', 1, 1, 75, 5, 5, 450, 450, 1, 1, 15, 1, 1, 1, 0, 0, -1, -1, 0, 1, 5, 10, 'Pretty good. A local repair man is called in to do the repairs. ', 'Overall it''s a great little place. Maintenance is good and the landlord is responsive. The only con is that it''s a little too far from campus.  ', 4),
(31, 'lol@student.nmt.edu', 4, -1, -1, '-1', 0, 1, -1, -1, 6, -1, -1, 0, 1, 0, 0, 0, 0, 1, 0, -1, -1, 0, 0, -5, -4, 'eh', 'k', 4),
(32, 'andrew.white@student.nmt.edu', 1200, 4, 2, 'One Year', 0, 2, 20, 0, 3, 450, 0, 0, 0, 7, 6, 1, 5, 1, 0, -1, -1, 0, 0, 7, 14, 'Piss god damn poor. ', '4/2000000000 lit \r\nGANG \r\nGANG \r\nGANG', 1),
(33, 'margaret.tinsley@student.nmt.edu', 550, 2, 2, '1 month', 0, 3, 50, 3, 1, 550, 550, 0, 0, 7, 1, 1, 8, 0, 0, -1, -1, 0, 0, 1, 2, 'Sam shows up within a couple days and fixes anything you need!  Always does a good job.', 'Cute little duplex. The kitchen is kinda small, but that is the only thing about the place that isn''t great.  Landlords are probably among the best in Socorro.  We''ve been very happy here.', 5),
(34, 'bryonna.klumker@student.nmt.edu', 300, 1, 1, 'One Month', 0, 1, 10, 4, 2, 600, 600, 1, 0, 7, 1, 1, 4, 1, 0, -1, -1, 0, 1, 1, 90, 'Great on landscape maintenance, terrible if you actually need something fixed', 'They''re pretty lenient and chill, until you need something fixed, or they think you slighted them in some way. Overall, it''s a pretty great place for the low price, but it''d be best if you have handiness skills so you don''t rely on the landlords completely.', 4),
(35, 'brandon.edwards@student.nmt.edu', 370, 1, 1, '1 year', 0, 2, 37, 3, 5, 370, 370, 0, 0, 7, 2, 1, 5, 1, 0, -1, -1, 0, 0, 0, 0, '0', 'Nice how with several small flaws such as cracked tiles.', 3),
(36, 'blah@student.nmt.edu', 800, 11, 1, 'One Semester', 1, 1, 800, 0, 5, 800, 0, 1, 1, 9, 1, 1, 12, 0, 0, -1, -1, 0, 1, 30, 10, 'Its great!!! ', 'were done !!!', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
 ADD PRIMARY KEY (`postNumber`), ADD UNIQUE KEY `postNumber` (`postNumber`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
 ADD PRIMARY KEY (`postNumber`), ADD UNIQUE KEY `postNumber` (`postNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
MODIFY `postNumber` int(16) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
